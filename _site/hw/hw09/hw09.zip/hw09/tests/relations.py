test = {
  'name': 'size',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          sqlite> select * from non_parents;
          fillmore|barack
          eisenhower|barack
          fillmore|clinton
          eisenhower|clinton
          eisenhower|delano
          abraham|eisenhower
          grover|eisenhower
          herbert|eisenhower
          herbert|fillmore
          fillmore|herbert
          eisenhower|herbert
          eisenhower|grover
          eisenhower|abraham
          delano|eisenhower
          clinton|eisenhower
          clinton|fillmore
          barack|eisenhower
          barack|fillmore
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      sqlite> .read hw09.sql
      """,
      'teardown': '',
      'type': 'sqlite'
    }
  ]
}